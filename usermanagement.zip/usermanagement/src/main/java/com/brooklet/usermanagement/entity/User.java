package com.brooklet.usermanagement.entity;



import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="USER")
public class User {
	@Id
	private Long userId;
	private String userFirstName;
	private String userLastName;
	private String userName;
	private String password;
}
