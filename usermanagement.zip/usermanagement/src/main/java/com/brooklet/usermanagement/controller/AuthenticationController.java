package com.brooklet.usermanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.brooklet.usermanagement.dto.AuthenticationRequest;
import com.brooklet.usermanagement.dto.AuthenticationResponse;
import com.brooklet.usermanagement.service.AuthenticationService;

@RestController
@RequestMapping("/user")
public class AuthenticationController {
	
	@Autowired
	AuthenticationManager authenticationManager;

	/*
	 * @Autowired private AuthenticationService authenticationService;
	 * 
	 * @PostMapping("/authenticate") public ResponseEntity<AuthenticationResponse>
	 * authenticateUser(@RequestBody AuthenticationRequest authenticationRequest){
	 * boolean flag = authenticationService.authenticateUser(authenticationRequest);
	 * if(flag) { return ResponseEntity.ok(new AuthenticationResponse("success"));
	 * }else { return ResponseEntity.ok(new
	 * AuthenticationResponse("Invalid UserName/Password")); } }
	 */
	
	@PostMapping("/authenticate")
	public String doAuthentication(@RequestBody AuthenticationRequest authenticationRequest) {
		Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenticationRequest.getUserName(), authenticationRequest.getPassword()));
		if(authentication.isAuthenticated()) {
			return "Success";
		}else {
			return "Invalid username/password";
		}
	}
}
