package com.brooklet.usermanagement.service;

import com.brooklet.usermanagement.dto.AuthenticationRequest;

public interface AuthenticationService {
	public boolean authenticateUser(AuthenticationRequest authenticationRequest);
}
