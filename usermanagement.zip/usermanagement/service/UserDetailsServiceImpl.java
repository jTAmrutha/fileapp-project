package com.brooklet.usermanagement.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.brooklet.usermanagement.entity.User;
import com.brooklet.usermanagement.repository.AuthenticateRepository;

public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	AuthenticateRepository authenticateRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		Optional<User> user = authenticateRepository.findByUserName(username);
		User myUser = user.get();

		UserDetails userDetails = org.springframework.security.core.userdetails.User.withUsername(myUser.getUserName())
				.password(myUser.getPassword()).build();
		System.out.println(myUser.getUserName() + ":" + myUser.getPassword());
		return userDetails;

	}

}
