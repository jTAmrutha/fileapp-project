package com.brooklet.usermanagement.service;

/*
 * import java.util.List;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Service;
 * 
 * import com.brooklet.usermanagement.dto.AuthenticationRequest; import
 * com.brooklet.usermanagement.entity.User; import
 * com.brooklet.usermanagement.repository.AuthenticateRepository;
 * 
 * @Service public class AuthenticationServiceImpl implements
 * AuthenticationService{
 * 
 * @Autowired private AuthenticateRepository authenticateRepository;
 * 
 * @Override public boolean authenticateUser(AuthenticationRequest
 * authenticationRequest) { List<User> userList =
 * authenticateRepository.findByUserName(authenticationRequest.getUserName());
 * User user = null; boolean flag = false; if(userList.size()!=0) { user =
 * userList.get(0);
 * if(user.getPassword().equals(authenticationRequest.getPassword())) { flag =
 * true; } } return flag; }
 * 
 * }
 */